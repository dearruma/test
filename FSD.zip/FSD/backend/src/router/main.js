import express from 'express';
import {
	postValidation,
	putValidation,
	taskIdValidation
} from '../helper/validationHelper';

import {
	getAllTasks,
	getTaskById,
	getAllParentTasks,
	addTask,
	updateTask,
	deleteTask
} from '../controllers/TaskController';

export default (app) => {
	const apiRoutes = express.Router();
	const TaskRoutes = express.Router();
	const ParentRoutes = express.Router();

	TaskRoutes.use((req, res, next) => {
		switch (req.method) {
			case 'GET':
				next();
				break;
			case 'POST':
				postValidation(req, res, next);
				break;
			case 'PUT':
				putValidation(req, res, next);
				break;
			case 'DELETE':
				taskIdValidation(req, res, next);
				break;
		}
	});

	app.use('/api', apiRoutes);
	apiRoutes.use('/tasks', TaskRoutes);
	apiRoutes.use('/parents', ParentRoutes);

	TaskRoutes.get('/', getAllTasks);
	TaskRoutes.get('/:id', getTaskById);
	ParentRoutes.get('/', getAllParentTasks);
	TaskRoutes.post('/', addTask);
	TaskRoutes.put('/:id', updateTask);
	TaskRoutes.delete('/:id', deleteTask);
} 