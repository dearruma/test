import { TasktablePipe } from './tasktable.pipe';

describe('TasktablePipe', () => {
  it('create an instance', () => {
    const pipe = new TasktablePipe();
    expect(pipe).toBeTruthy();
  });
});
